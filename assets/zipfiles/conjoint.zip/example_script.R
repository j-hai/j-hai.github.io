#---------------------------------------------------------
# Example Script for Conjoint Analysis
#---------------------------------------------------------

# Clear workspace
rm(list=ls())

# Set working directory
#setwd("")

# Load required packages
library(foreign)
library(estimatr)
library(cjoint)
library(ggplot2)
library(ggtext)
library(msm)

#---------------------------------------------------------
# AMCE Under Independent Randomization
#---------------------------------------------------------

# Load candidate conjoint data
d <- read.dta("candidate.dta", convert.factors = TRUE)

# Check the data
head(d)

#---------------------------------------------------------
# Estimate AMCE for Age
#---------------------------------------------------------

# Age variable is a factor, and the lowest level is "36"
# R will pick this as the reference category in the regression
table(d$atage)
levels(d$atage)

# Estimate AMCEs for age categories vs. the reference category (standard errors clustered by respondent)
lm_robust(rating ~ atage, data = d, clusters = resID)

# Change the reference category to the oldest age group
d$age_ch <- relevel(factor(d$atage), ref = "75")
levels(d$age_ch)

# Estimate AMCEs for age categories vs. the oldest reference category
lm_robust(rating ~ age_ch, data = d, clusters = resID)

#---------------------------------------------------------
# Estimate AMCEs for All Attributes
#---------------------------------------------------------

# Identify attribute variable names
at_vars <- grep("^at", names(d), value = TRUE)

# Create model formula for all attributes
formula <- as.formula(paste("rating ~", paste(at_vars, collapse = " + ")))

# Estimate AMCEs via regression
r <- lm_robust(formula, data = d, clusters = resID)
summary(r)

# Alternative: Use the cjoint package
results <- amce(formula, data = d[!is.na(d$rating), ], cluster = TRUE, respondent.id = "resID")
summary(results)
plot(results)

#---------------------------------------------------------
# Produce a Polished Figure
#---------------------------------------------------------

# Collect regression results into a data frame
r_df <- data.frame(summary(r)$coef)
r_df$names <- row.names(r_df)
r_df <- r_df[-which(r_df$names == "(Intercept)"), ]

# Add attribute names, base categories, and reference category info
r_df$attr <- NA
r_df$base <- NA
r_df$type <- 1

# Populate 'attr' and 'base' columns
for (i in seq_along(at_vars)) {
  sub <- r_df$names %in% grep(at_vars[i], r_df$names, value = TRUE)
  r_df$attr[sub] <- at_vars[i]
  r_df$base[sub] <- levels(d[[at_vars[i]]])[1]
  r_df$names[sub] <- gsub(at_vars[i], "", r_df$names[sub])
}

# Add index for sorting
r_df$index <- match(r_df$attr, unique(r_df$attr))

# Create a temporary data frame for missing baselines
r_temp <- data.frame(
  names = unique(r_df$base),
  index = seq_along(unique(r_df$attr)) - 0.5,
  attr  = unique(r_df$attr),
  Estimate = 0,
  CI.Lower = 0,
  CI.Upper = 0,
  type = 0
)

# Combine data frames and reorder
r_df <- rbind(r_df[, names(r_temp)], r_temp)
r_df <- r_df[order(r_df$index), ]

# Reverse the order of levels for plotting
r_df$names <- factor(r_df$names, levels = rev(unique(r_df$names)))
r_df$attr <- factor(r_df$attr, levels = unique(r_df$attr), labels = c(
  "Military", "Religion", "Education", "Profession",
  "Income", "Race", "Age", "Gender"
))
r_df$type <- factor(r_df$type)

# Create the plot
p <- ggplot(r_df, aes(y = names, x = Estimate, xmin = CI.Lower, xmax = CI.Upper, color = attr, shape = type)) + 
  facet_grid(attr ~ ., scales = "free", space = "free") +
  geom_vline(xintercept = 0, color = grey(0.6)) +
  geom_errorbar(position = position_dodge(width = 0.5), width = 0.5) + 
  geom_point(position = position_dodge(width = 0.5), size = 3) + 
  xlab("AMCE on Candidate Rating (0-1)") + 
  ylab("") +
  theme(
    legend.position = "none",
    axis.text.y = element_text(size = 11),
    axis.text.x = element_text(size = 12),
    axis.title.x = element_text(size = 14),
    strip.text.y = element_text(size = 15,angle = 0)
  ) + 
  coord_cartesian(xlim = c(-0.15, 0.15)) +
  scale_shape_manual(values = c(21, 19))
p

# Save the plot
ggsave("fig.pdf", plot = p, width = 10, height = 8)

#---------------------------------------------------------
# AMCE Under Conditional Randomization
#---------------------------------------------------------

# Load immigration conjoint data
data("immigrationconjoint")
d <- immigrationconjoint

# Transform the outcome variable to numeric
d$Chosen_Immigrant <- as.numeric(d$Chosen_Immigrant)

# Estimate ACME using regression for a randomly assigned attribute (e.g., language skills)
lm_robust(Chosen_Immigrant ~ `Language Skills`, data = d, clusters = CaseID)

# Estimate ACME for attribute with randomization restriction (e.g., education and jobs)
table(d$Job, d$Education)

# Interaction regression for education and job
lmout <- lm(Chosen_Immigrant ~ Education * Job, data = d)
summary(lmout)

# get coefs and VCOV matrix for delta method
estmean <- na.omit(coef(lmout))
estvar  <- vcovCL(lmout, cluster = ~ d$CaseID)

# Example: ACME of going from no formal (FeatEd=1) to college degree (FeatEd=6)
# by computing weighted average of educ effect in each non-emtpty job stratum
# since high skilled jobs are not valid for no formal education, we only average over low skilled job strata
# and exclude high skilled jobs (i.e. numbers 5 Financial analyst, 8 Computer programmer, 10 Research scientist, and 11 Doctor)

# get terms we need for effect
terms <- c("Educationcollege degree",
           "Educationcollege degree:Jobwaiter",
           "Educationcollege degree:Jobchild care provider",
           "Educationcollege degree:Jobgardener",           
           "Educationcollege degree:Jobconstruction worker",
           "Educationcollege degree:Jobteacher",
           "Educationcollege degree:Jobnurse"
)
# get positions
pos <- (1:length(estmean))[names(estmean) %in% terms ]
names(estmean)[pos]
# effect formula
g <- as.formula(paste("~",paste(paste("x",pos[1],"+",sep="")),
                      paste("1/7*(",
                            paste("x",pos[2:length(pos)],sep="",collapse="+")
                            ,")",sep="")
))
g

# ACME estimate
estmean[terms][1]+sum(estmean[terms][2:length(terms)])*1/7
# SE of ACME
deltamethod(g, estmean, estvar, ses=TRUE)

# Estimate AMCE for immigration conjoint data

# Immigration Choice Conjoint Experiment Data from Hainmueller et. al. (2014).
data("immigrationdesign")
results <- amce(Chosen_Immigrant ~ Education + Job, data = immigrationconjoint, cluster = TRUE, respondent.id = "CaseID", design = immigrationdesign)
summary(results)

#---------------------------------------------------------
# Subgroup Analysis: Conditional AMCEs
#---------------------------------------------------------

# Create a low and high indicator for ethnocentrism
d <- immigrationconjoint
d <- na.omit(d)
d$ethnogroup <- as.numeric(d$ethnocentrism > median(d$ethnocentrism)) + 1

table(d$ethnogroup)

# run AMCEs in each sub-sample
r_df <- list()
for(i in 1:2){
  results <- amce(Chosen_Immigrant ~  Gender + Education + `Language Skills` +
                    `Country of Origin` + Job + `Job Experience` + `Job Plans` +
                    `Reason for Application` + `Prior Entry`,
                  data=d[d$ethnogroup==i,], na.ignore = TRUE,
                  cluster=TRUE,design=immigrationdesign,
                  respondent.id="CaseID"
  )
  # store and add index for sorting
  res          <- data.frame(summary(results)$amce,ethnogroup=i)
  res$index    <- match(res$Attribute, unique(res$Attribute))
  res$type=1
  
  # add baseline cats for plotting
  restemp <- data.frame(Estimate=0,Std..Err=0,Attribute=unique(res$Attribute),
                        Level=unlist(results$baselines),ethnogroup=i,
                        index=seq_along(unique(res$Attribute)) - 0.5,
                        type=0) 
  
  res <- rbind(res[,names(restemp)],restemp)
  res <- res[order(res$index),]
  r_df[[i]] <- res
}

# combine estimates
r_df <- do.call(rbind, r_df)

# create factors for plotting
r_df$ethnogroup <- factor(r_df$ethnogroup,levels=1:2,labels=c("Ethnocentrism: Low","Ethnocentrism: High"))
r_df$CI.Lower <-  r_df$Estimate - 1.96* r_df$Std..Err  
r_df$CI.Upper <-  r_df$Estimate + 1.96* r_df$Std..Err  
r_df$Level <-factor(r_df$Level,levels=rev(unique(r_df$Level)))
r_df$Attribute <-factor(r_df$Attribute)
r_df$type=factor(r_df$type)

p <- ggplot(r_df, aes(y = Level, x = Estimate, xmin = CI.Lower, xmax = CI.Upper, color = Attribute,shape=type)) + 
  facet_grid(Attribute ~ ethnogroup, scales = "free", space = "free") +
  geom_vline(xintercept = 0, color = grey(0.6)) +
  geom_errorbar(position = position_dodge(width = 0.5), width = 0.5) + 
  geom_point(position = position_dodge(width = 0.5), size = 3) + 
  xlab("AMCE on Candidate Rating (0-1)") + 
  ylab("") +
  theme(
    legend.position = "none",
    axis.text.y = element_text(size = 11, angle = 0, hjust = 1),
    axis.text.x = element_text(size = 12),
    axis.title.x = element_text(size = 14),
    strip.text.y = element_text(size = 12, angle = 0),
    strip.text = element_text(size = 16)  
  ) + 
  coord_cartesian(xlim = c(-0.3, 0.3)) +
  scale_shape_manual(values = c(21, 19), guide = "none")
p

# Save the plot
ggsave("figcond.pdf", plot = p, width = 10, height = 8)

#---------------------------------------------------------
# Marginal Means
#---------------------------------------------------------

# Example attribute: Jobs
res <- lm_robust(Chosen_Immigrant ~ 0 + Job, data = d, clusters = CaseID)

# Create data frame from regression results
r_df <- data.frame(summary(res)$coeff)
r_df$Attribute <- levels(d$Job)     

# Plot marginal means for job categories
p <- ggplot(r_df, aes(y = Attribute, x = Estimate, xmin = CI.Lower, xmax = CI.Upper)) + 
  geom_vline(xintercept = 0.5, color = grey(0.6)) +
  geom_errorbar(width = 0.5) + 
  geom_point(size = 3) + 
  xlab("Marginal Mean Level of Support (0-1)") +
  ylab("") +
  theme(
    legend.position = "none",
    axis.text.y = element_text(size = 11, hjust = 1),
    axis.text.x = element_text(size = 12),
    axis.title.x = element_text(size = 14)
  ) + 
  coord_cartesian(xlim = c(0.25, 0.75)) 

# Save plot
ggsave("figmmjob.pdf", plot = p, width = 10, height = 8)

#---------------------------------------------------------
# Subgroup Marginal Means: By Ethnocentrism
#---------------------------------------------------------

# Check the distribution of the ethnogroup variable
table(d$ethnogroup)

# Estimate means by subgroup (Ethnocentrism: Low and High)
et_lo <- lm_robust(Chosen_Immigrant ~ 0 + Job, data = d[d$ethnogroup == 1,], clusters = CaseID)
et_hi <- lm_robust(Chosen_Immigrant ~ 0 + Job, data = d[d$ethnogroup == 2,], clusters = CaseID)

# Combine results from both subgroups
r_df <- data.frame(rbind(summary(et_lo)$coeff, summary(et_hi)$coeff))
r_df$ethnogroup <- rep(c(1, 2), each = length(unique(d$Job)))
r_df$Attribute <- rep(levels(d$Job), 2)     
r_df$ethnogroup <- factor(r_df$ethnogroup, levels = 1:2, labels = c("Ethnocentrism: Low", "Ethnocentrism: High"))

# Plot subgroup marginal means
p <- ggplot(r_df, aes(y = Attribute, x = Estimate, xmin = CI.Lower, xmax = CI.Upper, color = ethnogroup, shape = ethnogroup)) + 
  geom_vline(xintercept = 0.5, color = grey(0.6)) +
  geom_errorbar(position = position_dodge(width = 0.5), width = 0.5) + 
  geom_point(position = position_dodge(width = 0.5), size = 3) + 
  xlab("Marginal Mean Level of Support (0-1)") +
  ylab("") +
  theme(
    axis.text.y = element_text(size = 11, hjust = 1),
    axis.text.x = element_text(size = 12),
    axis.title.x = element_text(size = 14)
  ) + 
  coord_cartesian(xlim = c(0.25, 0.75)) 

# Save the plot
ggsave("figmmsubjob.pdf", plot = p, width = 10, height = 8)

#---------------------------------------------------------
# Subgroup Marginal Means for All Attributes
#---------------------------------------------------------

# Attributes for analysis
attr <- c("Gender", "Education", "`Language Skills`", "`Country of Origin`", "Job", "`Job Experience`", "`Job Plans`", "`Reason for Application`", "`Prior Entry`")

# Loop over attributes and subgroups to compute marginal means
r_df <- list()
for (k in 1:2) {
  res <- list()
  for (i in 1:length(attr)) {
    form <- as.formula(paste("Chosen_Immigrant ~ 0 +", paste(attr[i])))
    restemp <- data.frame(summary(lm_robust(form, data = d[d$ethnogroup == k,], clusters = CaseID))$coeff)
    restemp$Level <- levels(d[, gsub("`", "", attr[i])])
    restemp$Attribute <- gsub("`", "", attr[i])
    res[[i]] <- restemp
  }
  r_df[[k]] <- do.call(rbind, res)
  r_df[[k]]$ethnogroup <- k
}
r_df <- do.call(rbind, r_df)

# Plot marginal means for all attributes by subgroup
r_df$ethnogroup <- factor(r_df$ethnogroup, levels = 1:2, labels = c("Ethnocentrism: Low", "Ethnocentrism: High"))
r_df$Level <- factor(r_df$Level, levels = rev(unique(r_df$Level)))
r_df$Attribute <- factor(r_df$Attribute)

p <- ggplot(r_df, aes(y = Level, x = Estimate, xmin = CI.Lower, xmax = CI.Upper, color = Attribute, shape = ethnogroup)) + 
  facet_grid(Attribute ~ ., scales = "free", space = "free") +
  geom_vline(xintercept = 0.5, color = grey(0.6)) +
  geom_errorbar(position = position_dodge(width = 0.5), width = 0.5) + 
  geom_point(position = position_dodge(width = 0.5), size = 3) + 
  xlab("Marginal Mean Support (0-1)") + 
  ylab("") +
  theme(
    legend.position = "top",
    axis.text.y = element_text(size = 11, hjust = 1),
    axis.text.x = element_text(size = 12),
    axis.title.x = element_text(size = 14),
    strip.text.y = element_text(size = 12, angle=0),
    strip.text = element_text(size = 16)
  ) + 
  coord_cartesian(xlim = c(0.25, 0.75)) +
  guides(color = "none") +
  scale_shape_manual(name="",values = c(21, 19))

# Save the plot
ggsave("figmmall.pdf", plot = p, width = 10, height = 8)



#---------------------------------------------------------
# Illustrate Optimal Profile
#---------------------------------------------------------
library(BART)
library(fastDummies)

# Load and clean the data
d <- read.dta("candidate.dta", convert.factors = TRUE)
d <- na.omit(d)

# Check the data
head(d)

# Extract predictor variables and create dummy variables
at_vars <- grep("^at", names(d), value = TRUE)
d_df <- dummy_cols(d[, at_vars], remove_first_dummy = TRUE, remove_selected_columns = TRUE)

# Fit a BART model to predict candidate ratings
gout <- gbart(x.train = d_df, y.train = d$rating)

# Create All Possible Candidate Profiles
testfactor <- expand.grid(
  atmilitary = levels(d$atmilitary),
  atreligion = levels(d$atreligion),
  ated = levels(d$ated),
  atprof = levels(d$atprof),
  atinc = levels(d$atinc),
  atrace = levels(d$atrace),
  atage = levels(d$atage),
  atmale = levels(d$atmale)
)

# Create dummy variables for the candidate profiles
test <- dummy_cols(testfactor, remove_first_dummy = TRUE, remove_selected_columns = TRUE)

# Predict ratings for all candidate profiles using the BART model
pout <- predict(gout, newdata = test)
pred.rating <- colMeans(pout)

# Plot the distribution of predicted ratings
hist(pred.rating, main = "Histogram of Ratings", xlab = "Predicted Candidate Rating (0-1)")

# Identify the Optimal Candidate
testfactor$pred.rating <- pred.rating
testfactor <- testfactor[order(testfactor$pred.rating, decreasing = TRUE), ]
head(testfactor)  # Show the top 5 candidates based on predicted ratings

#---------------------------------------------------------
# Willingness to Pay (WTP) Analysis Using Multinomial and Mixed Logit
#---------------------------------------------------------
library(mlogit)

# Load the dataset
data("Train", package = "mlogit")

# Convert the dataset to 'mlogit' format
train.mlogit <- mlogit.data(Train, choice = "choice", shape = "wide",
                            varying = 4:11, sep = "_",
                            opposite = c("comfort"),
                            id.var = "id")

# Adjust units of price to Euros and time to hours
train.mlogit$price <- train.mlogit$price / 100 * 2.20371
train.mlogit$time <- train.mlogit$time / 60

#---------------------------------------------------------
# Estimate the Multinomial Logit Model
#---------------------------------------------------------
res <- mlogit(choice ~ price + change + comfort + time | 0, data = train.mlogit)

# Display model summary
summary(res)

# Extract coefficients
coef <- summary(res)$coefficients

#---------------------------------------------------------
# Calculate Willingness to Pay (WTP)
#---------------------------------------------------------
WTP_time <- coef["time"] / abs(coef["price"])
WTP_change <- coef["change"] / abs(coef["price"])
WTP_comfort <- coef["comfort"] / abs(coef["price"])

# Display WTP values
WTP_time
WTP_change
WTP_comfort

#---------------------------------------------------------
# WTP Analysis Using Mixed Logit
#---------------------------------------------------------

# Estimate the mixed logit model, assuming normal distribution for all random parameters
res <- mlogit(choice ~ price + time + change + comfort | -1, train.mlogit,
              panel = TRUE, rpar = c(price = "n", time = "n", change = "n", comfort = "n"), 
              R = 100, correlation = FALSE, halton = NA, method = "bhhh")

# Display model summary
summary(res)

# Marginal utility for travel time
marg.ut.time <- rpar(res, "time")
summary(marg.ut.time)

# Calculate WTP for an hour of travel time
wtp.time <- rpar(res, "time", norm = "price")
summary(wtp.time)

#---------------------------------------------------------
# WTP with Correlated Random Parameters
#---------------------------------------------------------
# Allow normals to be correlated in the mixed logit model
res <- mlogit(choice ~ price + time + change + comfort | -1, train.mlogit,
              panel = TRUE, rpar = c(price = "n", time = "n", change = "n", comfort = "n"), 
              R = 100, correlation = TRUE, halton = NA, method = "bhhh")

# Display model summary
summary(res)

# Marginal utility for travel time with correlated parameters
marg.ut.time <- rpar(res, "time")
summary(marg.ut.time)

# Calculate WTP for an hour of travel time with correlated parameters
wtp.time <- rpar(res, "time", norm = "price")
summary(wtp.time)

